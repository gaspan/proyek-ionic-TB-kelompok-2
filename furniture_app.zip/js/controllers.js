angular.module('app.controllers', [])
     
.controller('kursiCtrl', function($scope) {

})
   
.controller('mejaCtrl', function($scope) {

})
   
.controller('lemariCtrl', function($scope) {

})
   
.controller('ranjangCtrl', function($scope) {

})
 